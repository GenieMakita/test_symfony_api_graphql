

## Features

- Realtime Chat Application
- Light/dark mode based on your `prefers-color-scheme`
- Fullscreen mode
- Installable **PWA**
- Send Images and text
- Preview Image before Sending
- Full Responsiveness
- Identify Links
## Technologies used

<p>

<!-- <img width="100" src="https://cdn.iconscout.com/icon/free/png-256/react-1-282599.png">  -->
<img title="React JS" width="60" src="https://cdn4.iconfinder.com/data/icons/logos-3/600/React.js_logo-128.png" />
<img title="Firebase" width="60" src="https://cdn4.iconfinder.com/data/icons/google-i-o-2016/512/google_firebase-2-512.png"> 
<img title="Tailwind" width="60" src="https://cdn.icon-icons.com/icons2/2699/PNG/512/tailwindcss_logo_icon_167923.png"> 
</p>


## Run Locally


Install dependencies

```bash
  npm install
        or
  yarn
```

Start the server

```bash
  npm run start
```
