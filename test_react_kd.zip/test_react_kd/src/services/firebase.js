import firebase from "firebase";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage"

// Firebase Configs
const firebaseConfig = {
  apiKey: "AIzaSyDt0Ugl9K_y2p6kWAWRrkuZvvszMlz0CWQ",
  authDomain: "chattest-6000.firebaseapp.com",
  projectId: "chattest-6000",
  storageBucket: "chattest-6000.appspot.com",
  messagingSenderId: "984125860204",
  appId: "1:984125860204:web:6c732e9beb67394c796b49"
};

// Checking if app already initialize then don't initialize again
const app = !firebase.apps.length
  ? firebase.initializeApp(firebaseConfig)
  : firebase.app();

const db = app.firestore();
const auth = firebase.auth();
const googleProvider = new firebase.auth.GoogleAuthProvider();
const storage = firebase.storage();
export { db, auth, googleProvider, storage };
