<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiFilter;
use App\Repository\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Core\Annotation\ApiResource;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\SearchFilter;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints\Length;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[ORM\Table(name: '`user`')]
#[
    ApiResource(
        denormalizationContext:["groups"=>["user:write"]],
        paginationItemsPerPage: 20,
        collectionOperations:[
            "get"=>["normalization_context"=>['groups'=> ['users:read']]],
            "post"=>[],
        ],
        itemOperations:[
            "get"=>[],
            "put"=>[]
        ],
    ),
    ApiFilter( 
        SearchFilter::class, properties: [
            'email'=>'exact'
        ]
    )
]
class User
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(["users:read"])]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    #[Groups(["users:read","user:write"])]
    private ?string $email = null;

    #[ORM\Column(length: 255)]
    #[Groups(["v:read", "user:write"])]
    private ?string $firstname = null;

    #[ORM\Column(length: 255)]
    #[Groups(["users:read", "user:write"])]
    private ?string $lastname = null;

    #[ORM\Column(length: 255)]
    #[
        Groups(["users:read", "user:write"]),
        Length(min: 4)
    ]
    private ?string $password = null;

    #[ORM\OneToMany(mappedBy: 'user_from', targetEntity: Message::class)]
    private Collection $messages;

    public function __construct()
    {
        $this->messages = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getFirstname(): ?string
    {
        return $this->firstname;
    }

    public function setFirstname(string $firstname): self
    {
        $this->firstname = $firstname;

        return $this;
    }

    public function getLastname(): ?string
    {
        return $this->lastname;
    }

    public function setLastname(string $lastname): self
    {
        $this->lastname = $lastname;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    /**
     * @return Collection<int, Message>
     */
    public function getMessages(): Collection
    {
        return $this->messages;
    }

    public function addMessage(Message $message): self
    {
        if (!$this->messages->contains($message)) {
            $this->messages->add($message);
            $message->setUserFrom($this);
        }

        return $this;
    }

    public function removeMessage(Message $message): self
    {
        if ($this->messages->removeElement($message)) {
            // set the owning side to null (unless already changed)
            if ($message->getUserFrom() === $this) {
                $message->setUserFrom(null);
            }
        }

        return $this;
    }
}
