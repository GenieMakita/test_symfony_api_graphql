<?php

namespace App\Entity;

use App\Repository\MetadataRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Core\Annotation\ApiResource;

#[ORM\Entity(repositoryClass: MetadataRepository::class)]
#[ApiResource]
class Metadata
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?User $userm = null;

    #[ORM\ManyToOne(inversedBy: 'metadatas')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Message $message = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $readdate = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUserm(): ?User
    {
        return $this->userm;
    }

    public function setUserm(?User $userm): self
    {
        $this->userm = $userm;

        return $this;
    }

    public function getMessage(): ?Message
    {
        return $this->message;
    }

    public function setMessage(?Message $message): self
    {
        $this->message = $message;

        return $this;
    }

    public function getReaddate(): ?\DateTimeInterface
    {
        return $this->readdate;
    }

    public function setReaddate(\DateTimeInterface $readdate): self
    {
        $this->readdate = $readdate;

        return $this;
    }
}
